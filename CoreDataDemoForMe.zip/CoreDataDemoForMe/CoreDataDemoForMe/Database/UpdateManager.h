//
//  UpdateManager.h
//  CoreDataDemoForMe
//
//  Created by Lalji on 26/04/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface UpdateManager : NSObject

+ (void)saveContext:(NSManagedObjectContext*)theContext;
+ (void)saveOnlyChildContext:(NSManagedObjectContext*)theContext;
+ (NSManagedObjectContext *)privateConextFromParentContext:(NSManagedObjectContext*)parentContext;
+(NSNumber *)getNextIdFor:(NSString *)strEntity forColumn:(NSString *)strColumn withMOC:(NSManagedObjectContext *)moc;
+ (void)deleteFromContext:(NSManagedObjectContext*)theContext object:(NSManagedObject*)anObject;
@end
