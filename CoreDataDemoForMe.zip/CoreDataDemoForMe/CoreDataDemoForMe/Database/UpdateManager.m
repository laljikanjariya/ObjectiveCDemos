//
//  UpdateManager.m
//  CoreDataDemoForMe
//
//  Created by Lalji on 26/04/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import "UpdateManager.h"
#import "DatabaseManager.h"

@implementation UpdateManager



#pragma mark - CoreData wrappers

+ (void)saveContext:(NSManagedObjectContext*)theContext {
    if (theContext == nil) {
        return;
    }
    if (theContext.parentContext == nil) {
        [theContext performBlock:^{
            [self __save:theContext];
        }];
    } else {
        [theContext performBlockAndWait:^{
            [self __save:theContext];
        }];
    }
}
+ (void)saveOnlyChildContext:(NSManagedObjectContext*)theContext {
    @try {
        NSError *error = nil;
        if (![theContext save:&error]) {
            NSLog(@"Whoops, couldn't save: %@", error.localizedDescription);
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Save: Non recoverable error occured. %@", exception);
    }
    @finally {
        
    }
}
+ (void)__save:(NSManagedObjectContext *)theContext {
    [self saveOnlyChildContext:theContext];
    [self saveContext:theContext.parentContext];
}

+ (void)deleteFromContext:(NSManagedObjectContext*)theContext object:(NSManagedObject*)anObject {
    if (anObject != nil) {
        @try {
            [theContext deleteObject:anObject];
        }
        @catch (NSException *exception) {
            NSLog(@"Non recoverable error occured while deleting. %@", exception);
        }
        @finally {
            
        }
    }
}

+ (NSManagedObjectContext *)privateConextFromParentContext:(NSManagedObjectContext*)parentContext {
    // Create Provate context for this queue
    NSManagedObjectContext *privateManagedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    privateManagedObjectContext.parentContext = parentContext;
    [privateManagedObjectContext setUndoManager:nil];
    return privateManagedObjectContext;
}
+(NSNumber *)getNextIdFor:(NSString *)strEntity forColumn:(NSString *)strColumn withMOC:(NSManagedObjectContext *)moc{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:strEntity];
    
    fetchRequest.fetchLimit = 1;
    fetchRequest.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:strColumn ascending:NO]];
    
    NSError *error = nil;
    return @([[[moc executeFetchRequest:fetchRequest error:&error].firstObject valueForKey:strColumn] integerValue] + 1);
}
@end
