//
//  ProjectDetailHeaderVC.m
//  CoreDataDemoForMe
//
//  Created by Lalji on 05/05/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import "ProjectDetailHeaderVC.h"

@interface ProjectDetailHeaderVC ()
@property (weak, nonatomic) IBOutlet UITextField *txtProjectTitle;
@property (weak, nonatomic) IBOutlet UITextView *txtProjectDescription;
@property (weak, nonatomic) IBOutlet UICollectionView *collImages;

@end

@implementation ProjectDetailHeaderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated {
    self.txtProjectTitle.text = self.objProject.name;
    self.txtProjectDescription.text = self.objProject.projectDescription;
}
#pragma mark - UITextFieldDelegate -
- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField == self.txtProjectTitle) {
        self.objProject.name = textField.text;
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    return YES;
}
- (void)textViewDidBeginEditing:(UITextView *)textView {
    
    if (textView == self.txtProjectDescription) {
        self.objProject.projectDescription = textView.text;
    }
}
@end
