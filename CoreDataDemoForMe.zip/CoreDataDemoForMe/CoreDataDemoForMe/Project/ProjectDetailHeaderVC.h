//
//  ProjectDetailHeaderVC.h
//  CoreDataDemoForMe
//
//  Created by Lalji on 05/05/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Projects+CoreDataClass.h"

@interface ProjectDetailHeaderVC : UIViewController

@property(nonatomic,strong) Projects * objProject;
@property(nonatomic,strong) NSManagedObjectContext * privateMOC;

@end
