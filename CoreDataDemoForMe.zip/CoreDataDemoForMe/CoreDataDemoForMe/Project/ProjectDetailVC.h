//
//  ProjectDetailVC.h
//  CoreDataDemoForMe
//
//  Created by Lalji on 26/04/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DatabaseManager.h"

@interface ProjectDetailVC : UIViewController

@property(nonatomic,strong) Projects * objProject;
@property(nonatomic,strong) NSManagedObjectContext * privateMOC;

@end
@interface ProjectHeaderView : UITableViewCell

@property(nonatomic,weak)IBOutlet UITextField *txtProjectName;
@property(nonatomic,weak)IBOutlet UITextView *txtProjectDetail;
@end
