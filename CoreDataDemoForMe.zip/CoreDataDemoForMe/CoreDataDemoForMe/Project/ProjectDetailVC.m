//
//  ProjectDetailVC.m
//  CoreDataDemoForMe
//
//  Created by Lalji on 26/04/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import "ProjectDetailVC.h"
#import "ProjectDetailHeaderVC.h"
#import "UpdateManager.h"
#import "TaskDetailVC.h"
@interface ProjectDetailVC (){
    IBOutlet UITextField *txtName;
    IBOutlet UIButton *btnSave;
    NSArray <Tasks *>* arrTasks;
    IBOutlet UITableView * tblTaskList;
}

@end

@implementation ProjectDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = TRUE;
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    arrTasks = self.objProject.task.allObjects;
    [tblTaskList reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:TRUE];
}
-(IBAction)btnAddTask:(id)sender {

    NSManagedObjectContext * privateMOC = [UpdateManager privateConextFromParentContext:self.privateMOC];
    
    Tasks *object = [NSEntityDescription insertNewObjectForEntityForName:@"Tasks" inManagedObjectContext:privateMOC];
    object.taskID = [UpdateManager getNextIdFor:@"Tasks" forColumn:@"taskID" withMOC:privateMOC];
    object.created=[NSDate date];
    Projects * objPProject = [privateMOC objectWithID:self.objProject.objectID];
    object.project = objPProject;
    [objPProject addTaskObject:object];
    [self showProjectDetailViewFor:object withMOC:privateMOC];
}
-(void)showProjectDetailViewFor:(Tasks *)objeTask withMOC:(NSManagedObjectContext *)moc {
    TaskDetailVC * objTaskDetailVC =
    [[UIStoryboard storyboardWithName:@"Main" bundle:NULL] instantiateViewControllerWithIdentifier:@"TaskDetailVC_sid"];
    objTaskDetailVC.objTask = objeTask;
    objTaskDetailVC.privateMOC = moc;
    objTaskDetailVC.isFullSave = FALSE;
    [self.navigationController pushViewController:objTaskDetailVC animated:TRUE];
}
- (IBAction)saveProject:(id)sender {
    if (txtName.text.length > 0) {
        self.objProject.name = txtName.text;
        if (self.objProject.created == nil) {
            self.objProject.created = [NSDate date];
        }
        self.objProject.updated = [NSDate date];
        [UpdateManager saveContext:self.privateMOC];
        [self btnBack:nil];
    }
}
#pragma mark - Table view data source -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return arrTasks.count;
}
- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    ProjectDetailHeaderVC * objProjectDetailHeaderVC =
    [[UIStoryboard storyboardWithName:@"Main" bundle:NULL] instantiateViewControllerWithIdentifier:@"ProjectDetailHeaderVC_sid"];
    
    return objProjectDetailHeaderVC.view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"cell";
    
    UITableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Set up the cell...
    [self configureCell:cell atIndexPath:indexPath];
    
    return cell;
}
- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
    Tasks *task = [arrTasks objectAtIndex:indexPath.row];
    cell.textLabel.text = task.name;
    NSDateFormatter * formater=[[NSDateFormatter alloc]init];
    [formater setDateFormat:@"HH:mm:ss"];
    cell.detailTextLabel.text = [formater stringFromDate:task.created];
}
// Called after the user changes the selection.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSManagedObjectContext * privateMOC = [UpdateManager privateConextFromParentContext:self.privateMOC];
    Tasks *task = [arrTasks objectAtIndex:indexPath.row];
    [self showProjectDetailViewFor:[privateMOC objectWithID:task.objectID] withMOC:privateMOC];
}
@end


@implementation ProjectHeaderView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
@end
