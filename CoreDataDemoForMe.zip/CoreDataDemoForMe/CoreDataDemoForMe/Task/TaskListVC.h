//
//  TaskListVC.h
//  CoreDataDemoForMe
//
//  Created by Lalji on 26/04/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TaskListVC : UIViewController

@end
