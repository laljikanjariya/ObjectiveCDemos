//
//  TaskDetailVC.m
//  CoreDataDemoForMe
//
//  Created by Lalji on 26/04/18.
//  Copyright © 2018 Siya Infotech. All rights reserved.
//

#import "TaskDetailVC.h"
#import "UpdateManager.h"

@interface TaskDetailVC (){
    IBOutlet UITextField *txtName;
    IBOutlet UIButton *btnSave;
}

@end

@implementation TaskDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    txtName.text = self.objTask.name;
}
-(IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:TRUE];
}
- (IBAction)saveTask:(id)sender {
    if (txtName.text.length > 0) {
        self.objTask.name = txtName.text;
        if (self.objTask.created == nil) {
            self.objTask.created = [NSDate date];
        }
        self.objTask.updated = [NSDate date];
        if (self.isFullSave) {
            [UpdateManager saveContext:self.privateMOC];
        }
        else {
            [UpdateManager saveOnlyChildContext:self.privateMOC];
        }
        [self btnBack:nil];
    }
}
@end
