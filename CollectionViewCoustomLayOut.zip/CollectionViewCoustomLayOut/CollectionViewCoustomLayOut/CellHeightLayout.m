//
//  CellHeightLayout.m
//  CollectionViewCoustomLayOut
//
//  Created by Siya Infotech on 07/08/15.
//  Copyright (c) 2015 Siya Infotech. All rights reserved.
//

#import "CellHeightLayout.h"

@implementation CellHeightLayout

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSArray *attributes = [super layoutAttributesForElementsInRect:rect];
    NSMutableArray *newAttributes = [NSMutableArray arrayWithCapacity:attributes.count];
    for (UICollectionViewLayoutAttributes *attribute in attributes) {
        if ((attribute.frame.origin.x + attribute.frame.size.width <= self.collectionViewContentSize.width) &&
            (attribute.frame.origin.y + attribute.frame.size.height <= self.collectionViewContentSize.height)) {
            [newAttributes addObject:attribute];
        }
    }
    return newAttributes;
}
@end
