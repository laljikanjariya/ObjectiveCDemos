//
//  RapidGoogleSignIn.m
//  GoogleDriveDownload
//
//  Created by Siya-ios5 on 9/29/17.
//  Copyright © 2017 Siya-ios5. All rights reserved.
//

#import "RapidGoogleSignIn.h"
#import "GoogleDriveFile.h"
#import "RapidGoogleDriveOperation.h"

@interface RapidGoogleSignIn()<GIDSignInDelegate, GIDSignInUIDelegate>
@property (nonatomic, strong) GTLRDriveService *service;

@end

@implementation RapidGoogleSignIn


-(instancetype)init
{
    self = [super init];
    if (self) {
        GIDSignIn* signIn = [GIDSignIn sharedInstance];
        signIn.delegate = self;
        signIn.uiDelegate = self;
        signIn.scopes = [NSArray arrayWithObjects:kGTLRAuthScopeDriveReadonly, nil];
        [signIn signInSilently];
    }
    return self;
}

- (void)signIn:(GIDSignIn *)signIn
didSignInForUser:(GIDGoogleUser *)user
     withError:(NSError *)error {
    if (error != nil) {
        self.service.authorizer = nil;
    } else {
        self.service.authorizer = user.authentication.fetcherAuthorizer;
    }
}

-(void)fetchGoogleFileFromServer
{
    if (self.service.authorizer == nil) {
        NSLog(@"Service need to be authorizer");
        return;
    }
    
    RapidGoogleDriveOperation *rapidGoogleDriveOperation = [[RapidGoogleDriveOperation alloc]init];
    [rapidGoogleDriveOperation googleDriveFiles:^(NSError *error, NSMutableArray *files) {
       
        if (!error && files.count > 0) {
            NSLog(@"googleDriveFiles %@",files);
        }
        else
        {
            NSLog(@"Error while retriving Google Drive List  %@",error.localizedDescription);
        }
    }];
    
}


@end
