//
//  RapidGoogleDriveOperation.m
//  GoogleDriveDownload
//
//  Created by Siya-ios5 on 9/29/17.
//  Copyright © 2017 Siya-ios5. All rights reserved.
//

#import "RapidGoogleDriveOperation.h"
#import "GoogleDriveFile.h"

typedef void (^GoogleDriveCompletionHandler)(NSError *error, NSMutableArray *files) ;

@interface RapidGoogleDriveOperation()
@property (nonatomic, strong) GTLRDriveService *service;
@property (nonatomic, strong) GoogleDriveCompletionHandler googleDriveCompletionHandler;

@end


@implementation RapidGoogleDriveOperation

-(instancetype)initWithGoogleDriveService:(GTLRDriveService *)service
{
    self = [super init];
    if (self) {
        self.service = service;
    }
    return self;
}


- (void)googleDriveFiles:(void (^)(NSError *error, NSMutableArray *files))completionHandler;
{
    self.googleDriveCompletionHandler = completionHandler;
    
    GTLRDriveQuery_FilesList *query = [GTLRDriveQuery_FilesList query];
    query.fields = @"nextPageToken, files(id, name, mimeType,fileExtension)";
    self.service.shouldFetchNextPages = YES;
    [self.service executeQuery:query
                      delegate:self
             didFinishSelector:@selector(displayResultWithTicket:finishedWithObject:error:)];
}

// Process the response and display output
- (void)displayResultWithTicket:(GTLRServiceTicket *)ticket
             finishedWithObject:(GTLRDrive_FileList *)result
                          error:(NSError *)error {
    
    if (error == nil) {
        NSMutableArray *driveFiles = [[NSMutableArray alloc] init];
        if (result.files.count > 0) {
            for (GTLRDrive_File *file in result.files) {
                GoogleDriveFile *googleDriveFile = [[GoogleDriveFile alloc]initWithGTLRDriveFile:file];
                [driveFiles addObject:googleDriveFile];
            }
            self.googleDriveCompletionHandler(error, driveFiles);
        }
        else {
            self.googleDriveCompletionHandler(error, driveFiles);
        }
    } else {
        self.googleDriveCompletionHandler(error, nil);
    }
    
}



@end
