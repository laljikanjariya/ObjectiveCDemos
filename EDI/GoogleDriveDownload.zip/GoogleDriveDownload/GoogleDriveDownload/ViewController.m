//
//  ViewController.m
//  GoogleDriveDownload
//
//  Created by Siya-ios5 on 9/28/17.
//  Copyright © 2017 Siya-ios5. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) IBOutlet GIDSignInButton *signInButton;
@property (nonatomic, strong) UITextView *output;
@property (nonatomic, strong) GTLRDriveService *service;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Configure Google Sign-in.
    GIDSignIn* signIn = [GIDSignIn sharedInstance];
    signIn.delegate = self;
    signIn.uiDelegate = self;
    signIn.scopes = [NSArray arrayWithObjects:kGTLRAuthScopeDriveReadonly, nil];
    [signIn signInSilently];
    
    // Add the sign-in button.
    self.signInButton = [[GIDSignInButton alloc] init];
    [self.view addSubview:self.signInButton];
    
    // Create a UITextView to display output.
    self.output = [[UITextView alloc] initWithFrame:self.view.bounds];
    self.output.editable = false;
    self.output.font = [UIFont fontWithName:@"System" size:25.0];
    self.output.contentInset = UIEdgeInsetsMake(20.0, 0.0, 20.0, 0.0);
    self.output.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.output.hidden = true;
    [self.view addSubview:self.output];
    
    // Initialize the service object.
    self.service = [[GTLRDriveService alloc] init];
}

- (void)signIn:(GIDSignIn *)signIn
didSignInForUser:(GIDGoogleUser *)user
     withError:(NSError *)error {
    if (error != nil) {
        [self showAlert:@"Authentication Error" message:error.localizedDescription];
        self.service.authorizer = nil;
    } else {
        self.signInButton.hidden = true;
        self.output.hidden = false;
        self.service.authorizer = user.authentication.fetcherAuthorizer;
        [self listFilesWithPageToken:nil];
    }
}

// List up to 10 files in Drive
- (void)listFilesWithPageToken:(NSString *)pageToken {
    GTLRDriveQuery_FilesList *query = [GTLRDriveQuery_FilesList query];
    query.fields = @"nextPageToken, files(id, name, mimeType, fileExtension , fullFileExtension)";
    query.pageSize = 10;
    self.service.shouldFetchNextPages = YES;
    if (pageToken.length > 0) {
        query.pageToken = pageToken;
    }
    [self.service executeQuery:query
                      delegate:self
             didFinishSelector:@selector(displayResultWithTicket:finishedWithObject:error:)];
}

// Process the response and display output
- (void)displayResultWithTicket:(GTLRServiceTicket *)ticket
             finishedWithObject:(GTLRDrive_FileList *)result
                          error:(NSError *)error {
    
    NSMutableArray *fileIds = [[NSMutableArray alloc]init];
    NSMutableArray *mimeTypes = [[NSMutableArray alloc]init];

    if (error == nil) {
        NSMutableString *output = [[NSMutableString alloc] init];
        if (result.files.count > 0) {
            [output appendString:@"Files:\n"];
            int count = 1;
            for (GTLRDrive_File *file in result.files) {
                [output appendFormat:@"%@ (%@)\n\n\n\n", file.name, file.identifier];
                [mimeTypes addObject:file.mimeType];
                [fileIds addObject:file.identifier];

                NSLog(@"mimeType : %@",file.mimeType);
                NSLog(@"fileExtension : %@",file.fileExtension);
                NSLog(@"fullFileExtension : %@",file.fullFileExtension);


                count++;
            }
        } else {
            [output appendString:@"No files found."];
        }
        self.output.text = output;
    } else {
        NSMutableString *message = [[NSMutableString alloc] init];
        [message appendFormat:@"Error getting presentation data: %@\n", error.localizedDescription];
        [self showAlert:@"Error" message:message];
    }
    
    
    
    NSString *fileId = [fileIds objectAtIndex:2];
//    GTLRQuery *query = [GTLRDriveQuery_FilesGet queryForMediaWithFileId:fileId];
//    [_service executeQuery:query completionHandler:^(GTLRServiceTicket *ticket,
//                                                         GTLRDataObject *file,
//                                                         NSError *error) {
//        if (error == nil) {
//            NSLog(@"Downloaded %lu bytes", file.data.length);
//        } else {
//            NSLog(@"An error occurred: %@", error);
//        }
//    }];
    
    
    GTLRDriveQuery_FilesExport *query = [GTLRDriveQuery_FilesExport queryForMediaWithFileId:fileId
                                                                                   mimeType:@"application/vnd.oasis.opendocument.text"
];
    [_service executeQuery:query completionHandler:^(GTLRServiceTicket *ticket,
                                                         GTLRDataObject *file,
                                                         NSError *error) {
        if (error == nil) {
            NSLog(@"Downloaded %lu bytes", (unsigned long)file.data.length);
            
            NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
            NSString *documentsDirectory = [paths objectAtIndex:0];
            NSString *pathFloder = [[NSString alloc] initWithString:[NSString stringWithFormat:@"%@",@"new.doc"]];
            NSString *defaultDBPath = [documentsDirectory stringByAppendingPathComponent:pathFloder];
            NSData *tmp = file.data;
            [tmp writeToFile:defaultDBPath atomically:YES];

        } else {
            NSLog(@"An error occurred: %@", error);
        }
    }];


    
}


// Helper for showing an alert
- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:title
                                        message:message
                                 preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok =
    [UIAlertAction actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * action)
     {
         [alert dismissViewControllerAnimated:YES completion:nil];
     }];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
