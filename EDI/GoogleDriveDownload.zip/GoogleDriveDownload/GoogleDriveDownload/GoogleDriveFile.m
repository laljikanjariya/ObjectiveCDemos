//
//  GoogleDriveFile.m
//  GoogleDriveDownload
//
//  Created by Siya-ios5 on 9/29/17.
//  Copyright © 2017 Siya-ios5. All rights reserved.
//

#import "GoogleDriveFile.h"

@implementation GoogleDriveFile

-(instancetype)initWithGTLRDriveFile:(GTLRDrive_File *)file
{
    self = [super init];
    
    if (self) {
        self.fileExtension = file.fileExtension;
        self.name = file.name;
        self.identifier = file.identifier;
        self.mimeType = file.mimeType;
        self.fullFileExtension = file.fullFileExtension;
    }
    return self;
}
@end
