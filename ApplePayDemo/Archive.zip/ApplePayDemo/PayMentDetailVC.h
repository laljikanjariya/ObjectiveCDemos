//
//  PayMentDetailVC.h
//  ApplePayDemo
//
//  Created by Siya Infotech on 02/12/15.
//  Copyright © 2015 Siya Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PayMentDetailVC : UIViewController
@property (nonatomic ,strong) NSString * strID;
@end
