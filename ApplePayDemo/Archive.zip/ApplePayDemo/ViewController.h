//
//  ViewController.h
//  ApplePayDemo
//
//  Created by Siya Infotech on 01/12/15.
//  Copyright © 2015 Siya Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

