var hierarchy =
[
    [ "Car", "d6/d44/class_car.html", [
      [ "SmallCar", "de/dcf/interface_small_car.html", null ]
    ] ],
    [ "Car()", "d1/d89/category_car_07_08.html", null ],
    [ "NSObject", null, [
      [ "MathAPI", "df/d7d/interface_math_a_p_i.html", null ]
    ] ],
    [ "<UIApplicationDelegate>", null, [
      [ "AppDelegate", "dd/d52/interface_app_delegate.html", null ]
    ] ],
    [ "UIResponder", null, [
      [ "AppDelegate", "dd/d52/interface_app_delegate.html", null ]
    ] ],
    [ "UIViewController", null, [
      [ "ViewController", "d2/d60/interface_view_controller.html", null ]
    ] ],
    [ "ViewController()", "d9/dee/category_view_controller_07_08.html", null ]
];