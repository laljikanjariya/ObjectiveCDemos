var interface_small_car =
[
    [ "exteriorColor", "interface_small_car.html#a286abaea6871cde85bacc2e47fc31919", null ],
    [ "nickname", "interface_small_car.html#ad1033f82517211f319f7b32ca0008f9a", null ]
];