var category_view_controller_07_08 =
[
    [ "firstNumberField", "category_view_controller_07_08.html#afdb01433312d6957b5642ead0abcc900", null ],
    [ "funTitleLabel", "category_view_controller_07_08.html#a1ef022914e2412340ecaaa0b3d1e9211", null ],
    [ "secondNumberField", "category_view_controller_07_08.html#a08e26ac06941fdcd69176de116478ceb", null ],
    [ "sumLabel", "category_view_controller_07_08.html#a7436e65d71bab732655bcbe6418255b2", null ]
];