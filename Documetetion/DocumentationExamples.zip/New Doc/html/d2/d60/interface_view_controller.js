var interface_view_controller =
[
    [ "changeCarType:", "d2/d60/interface_view_controller.html#aa54507194ca12f221c64c8626b114945", null ],
    [ "car", "d2/d60/interface_view_controller.html#aa6bc7a298fc7c20538a2b91787969ae6", null ],
    [ "funTitle", "d2/d60/interface_view_controller.html#a2983301c81b8a147d15df749fab98724", null ]
];