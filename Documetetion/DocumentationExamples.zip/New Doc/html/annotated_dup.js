var annotated_dup =
[
    [ "AppDelegate", "dd/d52/interface_app_delegate.html", "dd/d52/interface_app_delegate" ],
    [ "Car", "d6/d44/class_car.html", null ],
    [ "Car()", "d1/d89/category_car_07_08.html", "d1/d89/category_car_07_08" ],
    [ "MathAPI", "df/d7d/interface_math_a_p_i.html", null ],
    [ "SmallCar", "de/dcf/interface_small_car.html", "de/dcf/interface_small_car" ],
    [ "ViewController", "d2/d60/interface_view_controller.html", "d2/d60/interface_view_controller" ],
    [ "ViewController()", "d9/dee/category_view_controller_07_08.html", "d9/dee/category_view_controller_07_08" ]
];