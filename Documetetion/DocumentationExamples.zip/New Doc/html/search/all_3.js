var searchData=
[
  ['firstnumberfield',['firstNumberField',['../d9/dee/category_view_controller_07_08.html#afdb01433312d6957b5642ead0abcc900',1,'ViewController()']]],
  ['funtitle',['funTitle',['../d2/d60/interface_view_controller.html#a2983301c81b8a147d15df749fab98724',1,'ViewController']]],
  ['funtitlelabel',['funTitleLabel',['../d9/dee/category_view_controller_07_08.html#a1ef022914e2412340ecaaa0b3d1e9211',1,'ViewController()']]]
];
