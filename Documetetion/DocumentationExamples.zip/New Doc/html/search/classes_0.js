var searchData=
[
  ['appdelegate',['AppDelegate',['../dd/d52/interface_app_delegate.html',1,'']]]
];
