var interface_app_delegate =
[
    [ "window", "dd/d52/interface_app_delegate.html#acf48ac24125e688cac1a85445cd7fac2", null ]
];