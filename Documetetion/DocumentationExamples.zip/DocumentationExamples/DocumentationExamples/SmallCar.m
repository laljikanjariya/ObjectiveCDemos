//
//  SmallCar.m
//  DocumentationExamples
//
//  Created by Siya Infotech on 10/09/15.
//  Copyright (c) 2015 Andrew Pereira. All rights reserved.
//

#import "SmallCar.h"

@implementation SmallCar

@end
